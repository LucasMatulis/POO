import javax.swing.*;

public class TarifaEconomica extends Tarifa{

    public double Valor(double precoVoo){

        return precoVoo;
    }

}
