import javax.swing.*;

public class Tarifa {

        private double valorBase;

        public double Valor(double precoVoo){

                return precoVoo;
        }
}
