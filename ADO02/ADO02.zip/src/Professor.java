public class Professor extends Pessoa{

    public void email(){

        System.out.println("Informando período de férias da instituição para o professor");

    }
}
