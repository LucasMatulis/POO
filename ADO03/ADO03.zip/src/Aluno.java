public class Aluno extends Pessoa{

    public void email(){

        System.out.println("Solicitando a presença do aluno na secretaria");

    }
}
