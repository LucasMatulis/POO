public class Funcionario extends Pessoa{


    public void email(){

        System.out.println("Convocando o funcionario para fazer exame médico");

    }
}
