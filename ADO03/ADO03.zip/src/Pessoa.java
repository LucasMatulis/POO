public class Pessoa {

    public void email(){

        System.out.println("Nenhum email enviado");

    }
}
